vim-atom-dark
=============

A vim theme inspired by Atom's default dark theme. Just clone this in your
`.vim` folder or drop the `colors/atom-dark.vim` file in your `colors/`.

![Imgur](http://i.imgur.com/xw0OZHB.png)

vim-starwars
============

One dark and one light colorscheme for vim